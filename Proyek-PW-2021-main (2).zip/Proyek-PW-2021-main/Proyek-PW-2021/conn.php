<?php 
    session_start();
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "proyek_pw_2021";
    $conn = mysqli_connect($host,$username,$password,$dbname);

    if(!$conn){
        die("Gagal Connect " . mysqli_connect_error());
    }

?>