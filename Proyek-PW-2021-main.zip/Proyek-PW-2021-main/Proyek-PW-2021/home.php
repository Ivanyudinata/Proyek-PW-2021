<?php  
    require_once("conn.php");
    if(isset($_REQUEST["btnsearch"])){
        $name = $_REQUEST["txtsearch"];
        $query = "SELECT * FROM products WHERE name = '$name'";
        $search = mysqli_query($conn,$query);
        
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php if(isset($_SESSION["userlogin"])) : ?>
        <h1>Selamat Datang, <?= $_SESSION["userlogin"]; ?></h1>
    <?php endif; ?>
    <button type="submit" name="btnlogout"><a href="index.php">Logout</a></button>
    <br>
    <form action="#" method="get">
        <input type="text" name="txtsearch" id="" placeholder="Name">
        <button type="submit" name="btnsearch">Search</button>
    </form>
    <h2>Daftar Barang</h2>
    <table border="1" cellspacing="0" cellpadding="1">
        <tr>
            <th>ID</th>
            <th>Kategori</th>
            <th>Name</th>
            <th>Description</th>
            <th>Harga</th>
            <th>Qty</th>
            <th>Warna</th>
            <th>Size</th>
        </tr>
            <?php foreach($search as $cari) : ?>
                <tr>
                    <td><?= $cari["id"]; ?></td>
                    <td><?= $cari["kategori"]; ?></td>
                    <td><?= $cari["name"]; ?></td>
                    <td><?= $cari["description"]; ?></td>
                    <td><?= $cari["harga"]; ?></td>
                    <td><?= $cari["qty"]; ?></td>
                    <td><?= $cari["warna"]; ?></td>
                    <td><?= $cari["size"]; ?></td>
                </tr>
            <?php endforeach; ?>
    </table>
</body>
</html>