<?php 
    require_once("conn.php");
    if(isset($_REQUEST["btnlogin"])){
        $username = $_REQUEST["txtuser"];
        $password = $_REQUEST["txtpass"];
        $query = "SELECT nama,username,password FROM customers WHERE username = '$username' AND password = '$password'";
        $login = mysqli_query($conn,$query);
        if(mysqli_num_rows($login)){
            while($row=mysqli_fetch_assoc($login)){
                $_SESSION["userlogin"] = $row["nama"];
            }
            header("Location:home.php");
        }
        else if($username=="admin" && $password=="admin"){
            header("Location:admin.php");
        }
        else{
            echo "<script>alert('Gagal Login')</script>";
        }
    }


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Login</h1>
    <form action="#" method="post">
        Username : <input type="text" name="txtuser" id=""><br>
        Password : <input type="password" name="txtpass" id=""><br>
        <button type="submit" name="btnlogin">Login</button><br>
        <p>Menuju ke halaman register <a href="register.php">Register</a></p>
    </form>
</body>
</html>