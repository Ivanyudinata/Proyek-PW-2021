<?php
    require_once("conn.php");
    if(isset($_REQUEST["btnkategori"])){
        $namakategori = $_REQUEST["txtnamakategori"];
        $query = "INSERT INTO kategori VALUES('','$namakategori')";
        $kategori = mysqli_query($conn,$query);
    }
    $query1 = "SELECT nama_kategori FROM kategori";
    $tampilkategori = mysqli_query($conn,$query1);
    if(isset($_REQUEST["btnaddproduct"])){
        $namaproduct = $_REQUEST["txtnamaproduct"];
        $harga = $_REQUEST["txtharga"];
        $qty = $_REQUEST["txtqty"];
        $kategori = $_REQUEST["cbkategori"];
        $warna = $_REQUEST["txtwarna"];
        $size = $_REQUEST["txtsize"];
        $deskripsi = $_REQUEST["txtdeskripsi"];
        $query2 = "INSERT INTO products VALUES('','$kategori','$namaproduct','$deskripsi','$harga','$qty','$warna','$size','','')";
        $tambahproduct = mysqli_query($conn,$query2);
    }
    $query3 = "SELECT * FROM products";
    $tampilproduct1 = mysqli_query($conn,$query3);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Selamat Datang, Admin</h1>
    <button type="submit" name="btnlogout"><a href="index.php">Logout</a></button>
    <h2>Kategori Barang</h2>
    <form action="#" method="get">
        Nama Kategori : <input type="text" name="txtnamakategori" id=""><br>
        <button type="submit" name="btnkategori">Add</button>
    </form>
    <h2>Master Barang</h2>
    <form action="#" method="get">
        Nama Product : <input type="text" name="txtnamaproduct" id=""><br>
        harga : <input type="number" name="txtharga" id=""><br>
        qty : <input type="number" name="txtqty" id=""><br>
        Kategori : 
        <select name="cbkategori" id="">
            <?php foreach($tampilkategori as $kategori) : ?>
                <option value=""><?= $kategori["nama_kategori"]; ?></option>
            <?php endforeach; ?>
        </select><br>
        warna : <input type="color" name="txtwarna" id=""><br>
        size : <input type="number" name="txtsize" id=""><br>
        Deskripsi :
        <br>
        <textarea name="txtdeskripsi" id="" cols="30" rows="10"></textarea><br>
        <button type="submit" name="btnaddproduct">Add Product</button>
    </form>
    <h2>Daftar Barang</h2><br>
    <table border="1" cellspacing="0" cellpadding="1">
        <tr>
            <th>Id Product</th>
            <th>Kategori</th>   
            <th>Nama Product</th>
            <th>Deskripsi</th>
            <th>Harga</th>
            <th>Qty</th>               
            <th>Warna</th>
            <th>Size</th>
            
        </tr>
        <?php foreach($tampilproduct1 as $product) : ?>
            <tr>
           
                <td><?= $product["id"] ?></td>
                <td><?= $product["kategori"] ?></td>
                <td><?= $product["name"] ?></td>
                <td><?= $product["description"] ?></td>
                <td><?= $product["harga"] ?></td>
                <td><?= $product["qty"] ?></td>   
                <td><?= $product["warna"] ?></td>
                <td><?= $product["size"] ?></td>
              
             </tr>
            <?php endforeach; ?>
    </table>
</body>
</html>