<?php  
    require_once("conn.php");
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php if(isset($_SESSION["userlogin"])) : ?>
        <h1>Selamat Datang, <?= $_SESSION["userlogin"]; ?></h1>
    <?php endif; ?>
    <button type="submit" name="btnlogout"><a href="index.php">Logout</a></button>
</body>
</html>