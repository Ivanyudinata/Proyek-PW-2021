<?php
    require_once("conn.php");
    if(isset($_REQUEST["btnregister"])){
        $nama = $_REQUEST["txtnama"];
        $username = $_REQUEST["txtuser"];
        $password = $_REQUEST["txtpass"];
        $email = $_REQUEST["txtemail"];
        $alamat = $_REQUEST["txtalamat"];
        $kota = $_REQUEST["txtkota"];
        $provinsi = $_REQUEST["txtprovinsi"];
        $kodepos = $_REQUEST["txtkodepos"];
        $imagepath = $_REQUEST["txtimagepath"];
        $query = "INSERT INTO customers VALUES('','$nama','$username','$password','$email','$alamat','$kota','$provinsi','$kodepos','$imagepath')";
        $register = mysqli_query($conn,$query);
        if($register){
            echo "<script>alert('Berhasil Register')</script>";
        }
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Register</h1>
    <form action="#" method="post">
        Nama     : <input type="text" name="txtnama" id=""><br>
        Username : <input type="text" name="txtuser" id=""><br>
        Password : <input type="password" name="txtpass" id=""><br>
        Email    : <input type="email" name="txtemail" id=""><br>
        Alamat   : <input type="text" name="txtalamat" id=""><br>
        Kota     : <input type="text" name="txtkota" id=""><br>
        Provinsi : <input type="text" name="txtprovinsi" id=""><br>
        Kode Pos : <input type="text" name="txtkodepos" id=""><br>
        Image Path : <input type="text" name="txtimagepath" id=""><br>
        <button type="submit" name="btnregister">Register</button><br>
        <p>Menuju ke halaman login <a href="index.php">Login</a></p>
    </form>
</body>
</html>